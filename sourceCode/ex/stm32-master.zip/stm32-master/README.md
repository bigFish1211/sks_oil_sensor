stm32 Develop
=============

#### [STM32F103VB](http://www.st.com/web/catalog/mmc/FM141/SC1169/SS1031/LN1565/PF164493) ####
[STM32F10x standard peripheral library - 3.5.0](http://www.st.com/web/en/catalog/tools/PF257890)    
[STM32 I2C Communication peripheral application library - 1.1.0](http://www.st.com/web/catalog/tools/FM147/CL1794/SC961/SS1743/PF257935)    
[STM32 MCUs Software](http://www.st.com/st-web-ui/active/en/catalog/tools/FM147/CL1794/SC961)    
[STM32F10xxx in-application programming using the USART](http://www.st.com/web/catalog/tools/FM147/CL1794/SC961/SS1743/PF257844)
